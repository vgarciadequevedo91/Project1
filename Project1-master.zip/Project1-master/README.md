# Project1

Group 5
-------
General Information:
This is a personal contact manager. The user should be able to log in/log out securely, add, delete, search, and view their contacts.


Authors:
-------
Vanessa Garcia, Brandon Haynes, Brandyn Brinston, Joel Gonzalez, Lauren Hastings, Zach Shea


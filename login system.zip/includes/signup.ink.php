<?php

if (isset($_POST['submit'])) {
	
	include_once 'dbh.ink.php';
	
	$first = mysqli_real_escape_string($conn, $_POST['firstName']);
	$last = mysqli_real_escape_string($conn, $_POST['lastName']);
	$uid = mysqli_real_escape_string($conn, $_POST['userName']);
	$pwd = mysqli_real_escape_string($conn, $_POST['password']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);

	if (empty($first) || empty($last) || empty($email) || empty($uid) || empty($pwd)) {
		header("Location: ../signup.php");
		exit();
	} else {
			if (!preg_match("/^[a-zA-Z]*$/", $first) || !preg_match("/^[a-zA-Z]*$/", $last)) {
				header("Location: ../signup.php");
				exit();
			} else {
				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
					header("Location: ../signup.php");
					exit();
				} else {
					$sql = "SELECT * FROM users WHERE userName='$uid'";
					$result = mysqli_query($conn, $sql);
					$resultCheck = mysqli_num_rows($result);
					
					if ($resultCheck > 0) {
						   		header("Location: ../index.html");
						exit();
					} else {
						$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

						$sql = "INSERT INTO users (firstName, lastName, userName, password, email) VALUES ('$first', '$last', '$uid', '$hashedPwd', '$email');";
						mysqli_query($conn, $sql);
						header("Location: ../index.html");
						exit();
					}
				}
			}
	}
	
} else {
	header("Location: ../signup.php");
	exit();
}
<section class="main-container">
	<div class="main-wrapper">
		<h2>Signup</h2>
		<form class="signup-form" action="includes/signup.ink.php" method="POST">
			<input type="text" name="firstName" placeholder="First Name">
			<input type="text" name="lastName" placeholder="Last Name">
			<input type="text" name="userName" placeholder="Username">
			<input type="password" name="password" placeholder="password">
			<input type="text" name="email" placeholder="E-mail">
			<button type="submit" name="submit">Sign up</button>
		</form>
	</div>
</section>
